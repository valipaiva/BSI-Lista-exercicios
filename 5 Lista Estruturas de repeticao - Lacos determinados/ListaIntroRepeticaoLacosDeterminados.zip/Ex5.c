/* Leia 6 valores. Em seguida, mostre quantos destes valores digitados foram positivos. Na proxima linha, deve-se
mostrar a media de todos os valores positivos digitados, com um dıgito apos o ponto decimal.*/
#include <stdio.h>

int main()
{
 int n,i;
 double n1,n2,n3,n4,n5,n6,media;

    for (i=0; i<n; i++){
    scanf("%lf", &n1);
    scanf("%lf", &n2);
    scanf("%lf", &n3);
    scanf("%lf", &n4);
    scanf("%lf", &n5);
    scanf("%lf", &n6);
        if (n1>0 || n2>0 || n3>0){
            media = (n1+n2+n3+n4+n5+n6)/6;
            printf("Media: %.1f\n", media);}
    }

 return 0;
}
