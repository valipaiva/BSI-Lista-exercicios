//Leia 2 valores inteiros x e y (suponha que x>y). A seguir, calcule e mostre quantos numeros impares existem entre eles.

#include<stdio.h>
int main()
{
    int x,y,aux,i;

    printf("Digite valor para x: ");
    scanf("%d",&x);
    printf("Digite valor para y: ");
    scanf("%d",&y);

    aux=x-y;

  for (i=0;i<aux;i++){
       if (i%2!=0)
        printf("%d\n",i);
    }


 return 0;
}

