/*O numero 3025 possui a seguinte caracter´ıstica: 30 + 25 = 55− > 55 ∗ 55 = 3025. Fazer um programa para obter
todos os numeros de 4 algarismos com a mesma caracterıstica do numero 3025.*/

#include<stdio.h>
int main()
{

    return 0;
}
