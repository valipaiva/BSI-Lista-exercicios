/*Chico tem 1,50 metro e cresce 2 centımetros por ano, enquanto Ze tem 1,10 metro e cresce 3 centımetros por ano.
Construa um programa que calcule e imprima quantos anos ser˜ao necessarios para que Ze seja maior que Chico.*/
#include <stdio.h>
int main()
{
    int cont=0;
    float altura_chico,altura_ze,n;

    printf("Altura do Chico: ");
    scanf ("%f",&altura_chico);

    printf("Altura do Ze: ");
    scanf ("%f",&altura_ze);

    while (altura_chico >= altura_ze){
        altura_ze = altura_ze+0.03;
        altura_chico = altura_chico+0.02;
        cont++;}

            if(altura_chico <= altura_ze)
                printf("Sao necessario %d anos",cont);

return 0;
}

