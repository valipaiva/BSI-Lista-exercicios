#include <stdio.h>

int main ()
{

    int valA,valB,soma;

    printf(" ");
    scanf("%d",&valA);

    printf(" ");
    scanf("%d",&valB);

    soma = valA+valB;

    printf("X = %d",soma);

    return 0;
}
