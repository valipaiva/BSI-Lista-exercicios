/*The formula to calculate the area of a circumference is defined as A = π . R2. Considering to this problem that π = 3.14159*/

#include <stdio.h>

int main ()
{

    float raio,PI=3.14159,area;

    printf("A= ");
    scanf("%f",&raio);

    area = PI*(raio*raio);

    printf("Valor da Area e: %.4f",area);

    return 0;
}
