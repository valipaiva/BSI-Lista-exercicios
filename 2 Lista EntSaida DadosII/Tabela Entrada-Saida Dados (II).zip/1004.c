/*Read two integer values. After this, calculate the product between them and store the result in a variable named PROD*/

#include <stdio.h>

int main ()
{

    int valA,valB,prod;

    printf("");
    scanf("%d",&valA);

    printf("");
    scanf("%d",&valB);

    prod = valA*valB;

    printf("Prod = %d",prod);

    return 0;
}
