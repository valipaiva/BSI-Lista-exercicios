/*Print the variable SOMA with all the capital letters,
with a blank space before and after the equal signal followed by the corresponding
value to the sum of A and B*/

#include <stdio.h>

int main ()
{

    int valA,valB,soma;

    printf("");
    scanf("%d",&valA);

    printf("");
    scanf("%d",&valB);

    soma = valA+valB;

    printf("Soma = %d",soma);

    return 0;
}
