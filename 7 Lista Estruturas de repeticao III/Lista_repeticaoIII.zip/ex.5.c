#include<stdio.h>
int main()
{
    int i,num,prox,cont;

    printf("Digite o valor de n: ");
    scanf("%d",&num);

    cont = 1;

    for (i=1; i<=num; i++){
        scanf("%d", &prox);}

        if (prox < num);{
            cont = 0;
            prox = num;
            printf("Sim");}

    return 0;
}
