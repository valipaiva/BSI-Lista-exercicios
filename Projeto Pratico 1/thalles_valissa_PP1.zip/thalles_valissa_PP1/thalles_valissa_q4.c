#include<stdio.h>
#include<stdlib.h>

main()                                                                                                              //Autor: Thalles Vaz Fluminhan
{                                                      //t = total       //nX = Xnesimo numero do cartao            //Matricula: 2128071
    char n;                                           //i contador de digitos       //ci = caractere errado
    int i=0,ci=0,t=0,n1,n2,n3,n4,q;
    printf("Escreva o numero do cartao:\n");
    while(n!='\n')         //loop que le os digitos do cartao
    {
        scanf("%c",&n);    //entrada de digito do cartao
        i++;               //contador de digitos do cartao

        if(n>=48&&n<=57)
        {
            n=n-48;
            if(i%2==0)    //digitos em posicao pares sao duplicados
            {
                if(n>=0&&n<=4)
                    t=t+(2*n);  //soma o digito ao total
                if(n>=5&&n<=9)
                    t=t+((2*n)-9);   //soma o digito ao total
            }
            if(i%2==1)  //digitos em posicao impares nao sao duplicados
                t=t+n;    //soma o digito ao total
            if(i==1)
                n1=n;    //atribui o primeiro caractere digitado ao primeiro digito do cartao para verificar a bandeira do cartao
            if(i==2)
                n2=n;    //atribui o segundo caractere digitado ao segundo digito do cartao para verificar a bandeira do cartao
            if(i==3)
                n3=n;    //atribui o terceiro caractere digitado ao terceiro digito do cartao para verificar a bandeira do cartao
            if(i==4)
                n4=n;    //atribui o quarto caractere digitado ao quarto digito do cartao para verificar a bandeira do cartao
        }
        else ci++;       //caso o caractere digitado nao seja um numero o contador de caractere invalido eh ativado
        if(n=='\n')
            ci--;
    }
    if(ci>=1){      //caso haja algum caractere invalido
        printf("caractere invalido ");
        printf("ci = %d ",ci);
    }
    else if(i<13)            //caso haja poucos caracteres
        printf("numero pequeno demais");
    else if(i>16)            //caso haja muitos caracteres
        printf("numero grande demais");
    else if(n1==5&&n2==1||n2==2||n2==3||n2==4||n2==5)     //verifica os primeiros digitos para conferir a bandeira
    {
        printf("MasterCard ");
        if(t%10==0)
            printf("valido");
        else
            printf("invalido");
    }
    else if(n1==4)                                        //verifica os primeiros digitos para conferir a bandeira
    {
        printf("Visa ");
        if(t%10==0)
            printf("valido");           //define o cartao como valido ou invalido
        else
            printf("invalido");
    }
    else if(n1==3&&n2==4||n2==7)                          //verifica os primeiros digitos para conferir a bandeira
    {
        printf("Amex ");
        if(t%10==0)
            printf("valido");           //define o cartao como valido ou invalido
        else
            printf("invalido");
    }
    else if(n1==3&&n2==0||n2==6||n2==8)                   //verifica os primeiros digitos para conferir a bandeira
    {
        printf("Diners ");
        if(t%10==0)
            printf("valido");           //define o cartao como valido ou invalido
        else
            printf("invalido");
    }
    else if(n1==6&&n2==0&&n3==1&&n4==1)                   //verifica os primeiros digitos para conferir a bandeira
    {
        printf("Discover");
        if(t%10==0)
            printf("valido");           //define o cartao como valido ou invalido
        else
            printf("invalido");
    }
    else if(n1==2&&n2==0&&n3==1&&n4==4)                   //verifica os primeiros digitos para conferir a bandeira
    {
        printf("enRoute");
        if(t%10==0)
            printf("valido");           //define o cartao como valido ou invalido
        else
            printf("invalido");
    }
    else if(n1==2,n2==1,n3==4,n4==9)                      //verifica os primeiros digitos para conferir a bandeira
    {
        printf("enRoute");
        if(t%10==0)
            printf("valido");           //define o cartao como valido ou invalido
        else
            printf("invalido");
    }
    else if(n1==3)                                        //verifica os primeiros digitos para conferir a bandeira
    {
        printf("JCB");
        if(t%10==0)
            printf("valido");           //define o cartao como valido ou invalido
        else
            printf("invalido");
    }
    else if(n1==2&&n2==1&&n3==3&&n4==1)                  //verifica os primeiros digitos para conferir a bandeira
    {
        printf("JCB");
        if(t%10==0)
            printf("valido");           //define o cartao como valido ou invalido
        else
            printf("invalido");
    }
    else if(n1==1&&n2==8&&n3==0&&n4==0)                  //verifica os primeiros digitos para conferir a bandeira
        if(t%10==0)
            printf("valido");           //define o cartao como valido ou invalido
        else
            printf("invalido");
}
