//Autor: Thalles Vaz Fluminhan
//Matricula: 2128071
//Autor: Valissa Rodrigues de Paiva
//Matricula: 2128098

#include<stdio.h>
main()
{
    int i;
    char r,c,d;
    printf("Codificar ou Decodificar?(c/d)\n");        //selecao menu de codificar ou decodificar
    scanf("%c", &r);

    if(r=='c')    //c = codificar
    {
        printf("Escreva a frase a ser codificada (nao se esqueca do ponto final!):\n");
        while(c!='.')
        {
            scanf(" %c", &c);        //infelizmente sem usar vetor entao teve que ser assim
            if(c==67||c==69||c==70||c==73||c==74||c==76||c==79||c==81||c==82||c==84||c==87||c==88||c==97||c==98||c==100||c==103||c==104||c==107||c==109||c==110||c==112||c==115||c==117||c==118||c==121||c==122)
                printf("%d ",c+128);  //converte os caracteres corrompidos
            else printf("%d ",c);     //imprime os caracteres nao corrompidos
        }
    }
    if(r=='d')      //d = decodificar
    {
        printf("Escreva a frase a ser decodificada\n");
        while(i!=46)       //46 = ponto final
        {
            scanf("%d", &i);
                if(i>=195)     //195 eh o primeiro caractere que sofre interfercia
                    printf("*");
                else printf("%c",i);  //caractere sem interferencia
        }
    }
}

//consulta: http://web.alfredstate.edu/faculty/weimandn/miscellaneous/ascii/ASCII%20Conversion%20Chart.gif
