#include<stdio.h>
#define SIZE (1<<4)
int main()
{
    int x,y,i;
    for(y=SIZE-1;y>=0;y--,putchar('\n')){
        for(i=0;i<y;i++)
            putchar(' ');
        for(x=0;x+y<SIZE;x++)
            printf((x & y) ? "  " : "* ");
    }
    return 0;
}

//Autor: Thalles Vaz Fluminhan
//Matricula: 2128071
//Autor: Valissa Rodrigues de Paiva
//Matricula: 2128098

//teste de mesa: (link)

/*
 -O caractere & serve para atribuir o valor de "e" (como se fosse o &&) soh que em valores binarios.
 -Ja o << serve para movimentar todos os bits '1' 4 vezes pra esquerda (00001 vira 10000 por exemplo), o que
se acaba por ser a mesma coisa que multiplicar o numero por 16 em logica binaria */

/* 1- Ira definir o size em 2^7 (ou seja, 128) ao inves de 2^4 (16) como consta no codigo original */

/* 2- Outra forma de resolver esse problema seria utilizando matrizes. Tambem sao possiveis algumas pequenas
alteracoes no codigo original que o deixam com a mesma funcionalidade, como por exemplo mudar o '#define SIZE (1<<4)'
para '#define SIZE 16' */

//consulta: https://pt.wikibooks.org/wiki/Programar_em_C/Operadores
//consulta: meus amigos Vosh e Jozo
