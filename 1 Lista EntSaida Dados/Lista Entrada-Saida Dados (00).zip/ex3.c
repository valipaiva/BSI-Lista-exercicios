/* linha 4 faltou " no final, antes de fechar o parenteses
linha 5 aux escrito em minusculo
linha 2 faltou ponto e virgula
linha 6 printf faltou o t
linha 7 faltou ponto e virgula
linha 6 & n�o precisa
linha 5 # trocar por % */

#include<stdio.h>

int main ()
{
    int aux;

    printf("Digite um numero inteiro: ");
    scanf("%d",&aux);
    printf("%d", aux);

    return 0;
}
