#include<stdio.h>

int main ()
{

    printf("Hello world!\n*\n***\n*****\n");

    return 0;
}
