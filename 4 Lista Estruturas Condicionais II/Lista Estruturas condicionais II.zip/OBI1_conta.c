#include<stdio.h>
int main()
{
    int consumo,conta;

    printf("Informe o consumo total em m3: \n");
    scanf("%d",consumo);

    if (consumo <= 10){
        conta = 7;}

    if (consumo >= 11 && consumo <=30){
        conta = 7 + (consumo%10);
    }

      if (consumo >= 31 && consumo <=100){
        conta = 7 + (consumo%10) + ((consumo%100)*2);
    }

       if (consumo >= 101){
        conta = 7 + (consumo%10) + ((consumo%100)*5);
    }
    return 0;
}
