#include<stdio.h>
#include<math.h>

int main()
{
    float a,b,c;

    printf("Digite 3 valores: ");
    scanf("%f%f%f",&a,&b,&c);

    if (pow(a,2) == (pow(b,2) + pow(c,2))){
        printf("Triangulo retangulo");
    }

    else
    if (pow(a,2) > (pow(b,2) + pow(c,2))){
        printf("Triangulo obtusangulo");
    }

    else
    if (pow(a,2) < (pow(b,2) + pow(c,2))){
        printf("Triangulo ocutangulo");
    }

     else
    if (a == b && b == c && a == c){
        printf("Triangulo equilatero");
    }

    else
    if (a == b || b == c || c == a){
        printf("Triangulo isoceles");
    }

    else
    if (pow(a,2) >= (pow(b,2) + pow(c,2))){
        printf("Nao forma triangulo");
    }

return 0;
}
