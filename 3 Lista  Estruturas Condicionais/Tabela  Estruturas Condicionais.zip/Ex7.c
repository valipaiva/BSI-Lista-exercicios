/* ler tres valores interos distintos e escrever em ordem crescente*/
#include<stdio.h>

int main()
{
    int a,b,c;

    printf("Digite tres valores inteiros: ");
    scanf("%d%d%d",&a,&b,&c);

    if (a<b && a<c && b<c){
        printf("%d%d%d",a,b,c);
    }

    if(a<b && a<c && c<b){
        printf("%d%d%d",a,c,b);
   }
    if(b<a && b<c && a<c){
        printf("%d%d%d",b,a,c);
   }

return 0;
}

